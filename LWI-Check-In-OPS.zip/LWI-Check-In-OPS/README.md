# LWI Check-In Operations

A standalone, browser-based airline check-in counter simulation. This is a separate project from the LWI gate-agent app. It runs without a backend, build system, packages, or network connection.

## Run it

Open `index.html` in a modern desktop browser. The demo data and changes are saved in that browser's local storage. Use **Flight board → Reset simulation** to restore the generated sample records.

## What is included

- **13 airline profiles:** United, American, JetBlue, Alaska, Southwest, Breeze, Delta, Frontier, Spirit, Allegiant, Sun Country, Hawaiian, and Avelo. The gate ranges and carrier-specific boarding group labels follow the LWI simulation setup.
- **26 seeded departures** with airline-specific colors, destination pairs, local departure times, gates, capacity, and passenger manifests.
- **Overview dashboard** with passenger, check-in, document-review, and baggage counts; upcoming flights; and a recent station pulse.
- **Flight board** with search, check-in totals, gate and capacity details, new-flight creation, and a counter launch action.
- **Passenger lookup** across flights using traveler name, record locator, flight number, or traveler ID.
- **Counter workflow** with a flight selector, passenger manifest, passenger profile/contact data, record locator, fare, seat, boarding group, document type/status, baggage, priority handling, and special-service request fields.
- **Seat assignment** on a 3–3 sample cabin map. Occupied seats are disabled, and check-in automatically assigns the first available seat if none was selected.
- **Baggage workflow** for adding/removing bags, generating simulated tag IDs, tracking estimated weight, and reprinting tags.
- **Document review** for marking a document reviewed or flagging a passenger for supervisor review. This is a training flag, not identity or travel-document validation.
- **Check-in and boarding-pass actions** with check-in reversal, boarding-pass reprint, and local activity history.
- **Walk-up passenger creation**, simulated agent notes, a station-wide exceptions list, and resettable sample data.

## Data and safety boundaries

This project is a UI simulation. It uses fictional sample passengers and local browser storage. It has no airline, airport, payment, identity-verification, passport/visa, Secure Flight, baggage-system, printer, or departure-control-system connection. Do not enter real traveler information. Baggage fees are not charged; print actions are logged as queued only.

## Project layout

- `index.html` — complete app, styles, generated demo records, and interactions.
- `README.md` — run instructions, included workflows, and simulation limitations.
